@echo off
copy c:\cac entrp\glwalker\*p.glw i:\qdls\adhoc\
move c:\cac entrp\glwalker\*p.glw c:\cacbakup\