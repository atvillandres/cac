REM ------------------------------------------------------
REM -      PLEASE DON'T MODIFY ANY ITEM IN THIS FILE
REM -      THIS IS USED FOR COPYING THE RAWDATA FOCUS FILES
REM -      THANKS
REM -      RUPERTO A. MENDOZA
REM -******************************************************

C:
CD \CACENT~1\Lextract\Target
COPY \CACENT~1\Lextract\RawData\%1 %2 /V /Y
