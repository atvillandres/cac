REM ------------------------------------------------------
REM -      PLEASE DON'T MODIFY ANY ITEM IN THIS FILE
REM -      THIS IS USED FOR COPYING THE REFRESH FILES
REM -      INTO DISKETTE
REM -      THANKS
REM -      RUPERTO A. MENDOZA
REM -******************************************************


COPY C:\CACENT~1\Lextract\ForFocus\%1 A: /V /Y
