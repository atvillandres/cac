REM Compressed the converted CAC DBF files

C:
CD \CACENT~1\NewCDR
DEL %1
ARJ A -y %1 *.DBF
DEL *.DBF