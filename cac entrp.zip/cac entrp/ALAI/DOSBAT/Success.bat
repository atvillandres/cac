REM ------------------------------------------------------
REM -      PLEASE DON'T MODIFY ANY ITEM IN THIS FILE     -
REM -      THIS IS USE FOR COPYING THE APLN CDR FILES    -
REM -      WITH NO ERROR                                 -
REM -      THANKS                                        -
REM -      RUPERTO A. MENDOZA
REM -                                                    -

C:
CD \CACENT~1\ALAI\Success
COPY %1 /V
DEL %1
CD \CACENT~1\ALAI\Error
DEL %2