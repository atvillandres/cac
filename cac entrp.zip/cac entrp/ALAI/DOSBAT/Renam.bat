REM EXTRACT FCS FILES
C:
CD \CACENT~1\ALAI\TRANEXT

REM ------------------------------------------------------
REM -      PLEASE DON'T MODIFY ANY ITEM IN THIS FILE     -
REM -      THIS IS USE FOR LOADING AHCI FOCUS FILE TO    -
REM -      COLLECTION AND CAS AR SYSTEM                  -
REM -                                                    -
REM -      THANKS                                        -
REM -      Opet Mendoza
REM -                                                    -
REM -      FILE NAMING CONVENTION                        -
REM -      R??????A.DBF =  RA.DBF  =  ORMAINCURR         -
REM -      R??????B.DBF =  RB.DBF  =  ORITEMCURR         -
REM -      R??????C.DBF =  RC.DBF  =  ORITEMDTLCURR      -
REM -      R??????D.DBF =  RD.DBF  =  ORCASHCURR         -
REM -      R??????E.DBF =  RE.DBF  =  ORCHECKCURR        -
REM -      R??????F.DBF =  RF.DBF  =  ORAPRCURR          -
REM -                                                    -
REM -      V??????A.DBF =  VA.DBF  =  DISMAINCURR        -
REM -      V??????B.DBF =  VB.DBF  =  DISITEMCURR        -
REM -      V??????C.DBF =  VC.DBF  =  DISITEMDTLCURR     -
REM -      V??????D.DBF =  VD.DBF  =  DISITEMDTLADDCURR  -
REM -      V??????E.DBF =  VE.DBF  =  DISITEMDTLDEDCURR  -
REM -      V??????F.DBF =  VF.DBF  =  DISCASHCURR        -
REM -      V??????G.DBF =  VG.DBF  =  DISCHECKCURR       -
REM -      V??????H.DBF =  VH.DBF  =  DISPLANCURR        -
REM -      V??????I.DBF =  VI.DBF  =  DISPLANCURR        -
REM -                                                    -
REM -      H??????A.DBF =  HA.DBF  =  HSDLPOR            -
REM -      D??????A.DBF =  DA.DBF  =  DSCURR             -
REM -      O??????A.DBF =  OA.DBF  =  LAMEND             -
REM -      RC??????.DBF =  RC1.DBF =  ORRTRNCURR         -
REM -      O??????B.DBF =  OB.DBF  =  LAPPLNOHIST        -
REM -                                                    -
REM -      ????????.CS  =  CS.DBF  =  CASH BALANCE       -
REM -                                                    -
REM -      FO-TCDBF.??? =  FO_TCDBF.DBF                  -
REM ------------------------------------------------------

DEL RA.DBF
RENAME R??????A.???    RA.DBF

DEL RB.DBF
RENAME R??????B.???    RB.DBF

DEL RC.DBF
RENAME R??????C.???    RC.DBF

DEL RD.DBF
RENAME R??????D.???    RD.DBF

DEL RE.DBF
RENAME R??????E.???    RE.DBF

DEL RF.DBF
RENAME R??????F.???    RF.DBF


DEL VA.DBF
RENAME V??????A.???    VA.DBF

DEL VB.DBF
RENAME V??????B.???    VB.DBF

DEL VC.DBF
RENAME V??????C.???    VC.DBF

DEL VD.DBF
RENAME V??????D.???    VD.DBF

DEL VE.DBF
RENAME V??????E.???    VE.DBF

DEL VF.DBF
RENAME V??????F.???    VF.DBF

DEL VG.DBF
RENAME V??????G.???    VG.DBF

DEL VH.DBF
RENAME V??????H.???    VH.DBF

DEL VI.DBF
RENAME V??????I.???    VI.DBF

DEL HA.DBF
RENAME H??????A.???    HA.DBF

DEL DA.DBF
RENAME D??????A.???    DA.DBF

DEL OA.DBF
RENAME O??????A.???    OA.DBF

REM DEL RC1.DBF
REM RENAME RC??????.???    RC1.DBF

DEL OB.DBF
RENAME O??????B.???    OB.DBF

DEL CS.DBF
RENAME *.CS     CS.DBF

DEL FO_TCDBF.DBF
RENAME FO-TCDBF.DBF    FO_TCDBF.DBF