@echo off
del c:\cacent~1\lextract\forfocus\ho\*.e*
del c:\cacent~1\lextract\forfocus\ho\*.dbf
cls
Echo This batch file assumes you have already extracted data in CAC 
Echo with a setting of 'ALL'.   Data disk for FO 100 (used by AP HO)
Echo will be produced using same data from in FOCUS003.em2
echo �
echo Press control-C to stop now or
pause
arj e c:\cacent~1\lextract\forfocus\focus003.em2 -va -y -g003531
arj a c:\cacent~1\lextract\forfocus\ho\focus100.em2 *.dbf -y -v1440k -g100531
del c:\cacent~1\lextract\forfocus\ho\*.dbf
echo �
Echo Finished!